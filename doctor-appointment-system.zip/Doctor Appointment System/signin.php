<?php include('header.php'); ?>





	<!-- this is for donor registraton -->
	<div class="main_content" style="background-color:#fff;">
		<h3 class="text-center" style="background-color:#272327;color: #fff;">User Login</h3>
		<div class="formstyles" style="background-color: #101011;color: #0d0623;">
				<div class="col-md-12">
					
					<div class="col-md-4"></div>
					<div class="col-md-4" style="float: right;padding:20px 115px;border: 1px solid lightgrey;margin-right:415px; margin-bottom:30px;background-color:#f3f3f8;color:#141313;">
						<h4 class="text-center;"><a href="patient_login.php">Patient login</a></h4>
						<h4 class="text-center;"><a href="doctors/doctorlogin.php">Doctor login</a></h4>
					</div>
					<div class="col-md-4"></div>
					
					
				</div>



		
          
    </div><br><br><br><br>
		
	
	
	

	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>





	
</body>
</html>